//
//  main.m
//  Signature Generator
//
//  Created by John Welch on 4/2/13.
//  Copyright (c) 2013 the / zimmerman / agency. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <AppleScriptObjC/AppleScriptObjC.h>

int main(int argc, char *argv[])
{
	[[NSBundle mainBundle] loadAppleScriptObjectiveCScripts];
	return NSApplicationMain(argc, (const char **)argv);
}
